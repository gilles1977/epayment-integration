﻿function GetShaSignature(formName) {
    
}