﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntegrationWeb.Models
{
    public class ScheduledPaymentViewModel
    {
        public string Amount1 { get; set; }
        public string Amount2 { get; set; }
        public string Amount3 { get; set; }
        public string ExecutionDate2 { get; set; }
        public string ExecutionDate3 { get; set; }
    }
}