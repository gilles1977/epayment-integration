﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace DomainModel
{
    public class Cart
    {
        private readonly IList<Product> _products;
        
        public Cart()
        {
            _products = new List<Product>();
        }

        public Cart(Product product)
        {
            _products = new List<Product>(new Product[] { product });
        }

        #region Properties

        public string OrderId { get; set; }

        [DisplayFormat(DataFormatString = "{0:0.000}")]
        public double Total
        {
            get
            {
                return
                    Math.Round(
                        _products.Where(p => !p.Recurring).Sum(p => p.Price), 3) + TotalSubscriptions;
            }
        }

        [DisplayFormat(DataFormatString = "{0:0.000}")]
        public double TotalSubscriptions
        {
            get { return Math.Round(_products.Where(p => p.Recurring).Sum(p => p.RecurringFee), 3); }
        }

        [DisplayFormat(DataFormatString = "{0:0.000}")]
        public double TotalScheduledPayments
        {
            get { return Math.Round(_products.Where(p => p.InstallementNumber > 0).Sum(p => p.Installement), 3); }
        }

        public int ItemCount { get { return _products.Count; } }

        public IList<Product> Products { get { return _products; } }

        public IList<Product> RecurringProducts { get { return _products.Where(p => p.RecurringPossible).ToList(); } }

        public IList<Product> SplittedProducts { get { return _products.Where(p => p.SplitPaymentPossible).ToList(); } }

        public bool HasRecurringProducts { get { return _products.Any(p => p.RecurringPossible); } }

        public bool HasRecurringSubscription { get { return _products.Any(p => p.Recurring); } }

        public bool HasSplitProducts { get { return _products.Any(p => p.SplitPaymentPossible); } }

        public bool HasInstallements { get { return _products.Any(p => p.InstallementNumber > 0); } }

        #endregion

        #region Methods

        public void Add(Product product)
        {
            product.CartProductId = Guid.NewGuid().ToString();
            _products.Add(product);
        }

        public bool Remove(int productId)
        {
            var product = _products.FirstOrDefault(p => p.ProductId == productId);
            if (product != null)
            {
                return _products.Remove(product);
            }
            return false;
        }

        public void Clear()
        {
            _products.Clear();
        }

        #endregion

        public Product this [string index]
        {
            get { return _products.FirstOrDefault(p => p.CartProductId == index); }
        }
    }
}
